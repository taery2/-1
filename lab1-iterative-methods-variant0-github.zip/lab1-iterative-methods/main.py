"""
Лабораторная работа №1.
Вариант 0.

Итерационные методы вычисления:
- квадратного корня методом Ньютона;
- кубического корня методом Ньютона;
- натурального логарифма степенным рядом.

Python 3.10+
"""

import math


EPS = 1e-6
N_MAX = 100


def sqrt_newton(a: float, eps: float = EPS, n_max: int = N_MAX):
    """Вычисляет sqrt(a) методом Ньютона."""
    if not isinstance(a, (int, float)):
        raise TypeError("Ошибка: a должно быть числом.")
    if a < 0:
        raise ValueError(
            "Ошибка: подкоренное выражение не может быть отрицательным."
        )
    if a == 0:
        return 0.0, 0

    x = a if a >= 1 else 1.0

    for n in range(1, n_max + 1):
        x_new = 0.5 * (x + a / x)

        if abs(x_new - x) < eps:
            return x_new, n

        x = x_new

    raise RuntimeError("Точность не достигнута за N_MAX итераций.")


def cbrt_newton(b: float, eps: float = EPS, n_max: int = N_MAX):
    """Вычисляет кубический корень методом Ньютона."""
    if not isinstance(b, (int, float)):
        raise TypeError("Ошибка: b должно быть числом.")
    if b == 0:
        return 0.0, 0

    sign = -1 if b < 0 else 1
    b_abs = abs(b)

    x = b_abs if b_abs >= 1 else 1.0

    for n in range(1, n_max + 1):
        x_new = (2 * x + b_abs / (x * x)) / 3

        if abs(x_new - x) < eps:
            return sign * x_new, n

        x = x_new

    raise RuntimeError("Точность не достигнута за N_MAX итераций.")


def ln_series(c: float, eps: float = EPS, n_max: int = 10000):
    """
    Вычисляет ln(c) по ряду:

        ln(c) = 2 * (y + y^3/3 + y^5/5 + ...)

    где y = (c - 1)/(c + 1).

    Возвращает (результат, число использованных членов).
    """
    if not isinstance(c, (int, float)):
        raise TypeError("Ошибка: c должно быть числом.")
    if c <= 0:
        raise ValueError(
            "Ошибка: аргумент логарифма должен быть положительным."
        )

    y = (c - 1) / (c + 1)
    y2 = y * y
    power = y
    total = 0.0

    for k in range(n_max):
        term = 2 * power / (2 * k + 1)

        if abs(term) < eps:
            return total, k

        total += term
        power *= y2

    raise RuntimeError("Точность не достигнута за n_max итераций.")


def print_iteration_table_sqrt(a: float, eps: float = EPS):
    """Печатает таблицу итераций для квадратного корня."""
    x = a if a >= 1 else 1.0

    print("\nИтерации для sqrt(a):")
    print(f"{'n':>3} {'x_n':>18} {'|x_n - x_(n-1)|':>22}")
    print(f"{0:>3} {x:>18.10f} {'—':>22}")

    for n in range(1, N_MAX + 1):
        x_new = 0.5 * (x + a / x)
        diff = abs(x_new - x)
        print(f"{n:>3} {x_new:>18.10f} {diff:>22.10e}")

        if diff < eps:
            break

        x = x_new


def print_iteration_table_cbrt(b: float, eps: float = EPS):
    """Печатает таблицу итераций для кубического корня."""
    b_abs = abs(b)
    x = b_abs if b_abs >= 1 else 1.0

    print("\nИтерации для cbrt(b):")
    print(f"{'n':>3} {'x_n':>18} {'|x_n - x_(n-1)|':>22}")
    print(f"{0:>3} {x:>18.10f} {'—':>22}")

    for n in range(1, N_MAX + 1):
        x_new = (2 * x + b_abs / (x * x)) / 3
        diff = abs(x_new - x)
        print(f"{n:>3} {x_new:>18.10f} {diff:>22.10e}")

        if diff < eps:
            break

        x = x_new


def main():
    # Данные варианта 0
    a = 2
    b = 10
    c = 5
    eps = 1e-6

    sqrt_value, sqrt_n = sqrt_newton(a, eps)
    cbrt_value, cbrt_n = cbrt_newton(b, eps)
    ln_value, ln_n = ln_series(c, eps)

    # math используется только для эталонных значений
    sqrt_ref = math.sqrt(a)
    cbrt_ref = b ** (1 / 3)
    ln_ref = math.log(c)

    print("=" * 96)
    print("ЛАБОРАТОРНАЯ РАБОТА №1 — ВАРИАНТ 0")
    print("=" * 96)

    print(
        f"{'Функция':<12}"
        f"{'Аргумент':>12}"
        f"{'Результат':>20}"
        f"{'Эталон':>20}"
        f"{'Погрешность':>18}"
        f"{'Итерации':>12}"
    )

    print(
        f"{'sqrt':<12}"
        f"{a:>12}"
        f"{sqrt_value:>20.12f}"
        f"{sqrt_ref:>20.12f}"
        f"{abs(sqrt_value - sqrt_ref):>18.4e}"
        f"{sqrt_n:>12}"
    )

    print(
        f"{'cbrt':<12}"
        f"{b:>12}"
        f"{cbrt_value:>20.12f}"
        f"{cbrt_ref:>20.12f}"
        f"{abs(cbrt_value - cbrt_ref):>18.4e}"
        f"{cbrt_n:>12}"
    )

    print(
        f"{'ln':<12}"
        f"{c:>12}"
        f"{ln_value:>20.12f}"
        f"{ln_ref:>20.12f}"
        f"{abs(ln_value - ln_ref):>18.4e}"
        f"{ln_n:>12}"
    )

    print_iteration_table_sqrt(a, eps)
    print_iteration_table_cbrt(b, eps)


if __name__ == "__main__":
    main()
